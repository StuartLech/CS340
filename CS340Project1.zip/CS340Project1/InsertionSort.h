#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

#include <vector>

void insertionSort(std::vector<int>& arr);

#endif


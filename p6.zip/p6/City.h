#ifndef CITY_H
#define CITY_H

class City {
public:
    int id;
    double x, y;

    City(int _id, double _x, double _y);
};

#endif // CITY_H

#include "City.h"

City::City(int _id, double _x, double _y) : id(_id), x(_x), y(_y) {}

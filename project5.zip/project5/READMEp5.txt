Stuart Lech 800728996 Slech@siue.edu
To run executable you need to set the path for dictionary txt and run it on Python 3.12
In my instance dictionary_path = "C:/Users/StLec/OneDrive/Desktop/dictionary.txt"